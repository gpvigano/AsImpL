var dir_1ad3ded29975ec9c18a6c03fcd5633b8 =
[
    [ "Loader.cs", "_loader_8cs.html", [
      [ "Loader", "class_as_imp_l_1_1_loader.html", "class_as_imp_l_1_1_loader" ],
      [ "BuildStats", "struct_as_imp_l_1_1_loader_1_1_build_stats.html", "struct_as_imp_l_1_1_loader_1_1_build_stats" ],
      [ "Stats", "struct_as_imp_l_1_1_loader_1_1_stats.html", "struct_as_imp_l_1_1_loader_1_1_stats" ]
    ] ],
    [ "LoaderObj.cs", "_loader_obj_8cs.html", [
      [ "LoaderObj", "class_as_imp_l_1_1_loader_obj.html", "class_as_imp_l_1_1_loader_obj" ]
    ] ],
    [ "TextureLoader.cs", "_texture_loader_8cs.html", [
      [ "TextureLoader", "class_as_imp_l_1_1_texture_loader.html", "class_as_imp_l_1_1_texture_loader" ]
    ] ]
];