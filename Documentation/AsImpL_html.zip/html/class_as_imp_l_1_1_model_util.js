var class_as_imp_l_1_1_model_util =
[
    [ "MtlBlendMode", "class_as_imp_l_1_1_model_util.html#a121bd9cb3ac8c5ca1fb724bd12f7bfea", [
      [ "OPAQUE", "class_as_imp_l_1_1_model_util.html#a121bd9cb3ac8c5ca1fb724bd12f7bfeaaf05b252996befbe2cb461cc80c9ccbed", null ],
      [ "CUTOUT", "class_as_imp_l_1_1_model_util.html#a121bd9cb3ac8c5ca1fb724bd12f7bfeaa68a58e6f616a803e0fb6dcbb29d83673", null ],
      [ "FADE", "class_as_imp_l_1_1_model_util.html#a121bd9cb3ac8c5ca1fb724bd12f7bfeaa2445ee3d2e9877a973fe794a6b76c346", null ],
      [ "TRANSPARENT", "class_as_imp_l_1_1_model_util.html#a121bd9cb3ac8c5ca1fb724bd12f7bfeaa6dbf1b8bc39b4ed513395a18b554979f", null ]
    ] ],
    [ "DetectMtlBlendFadeOrCutout", "class_as_imp_l_1_1_model_util.html#af65b3e0a8f8d84e1d3fc1ac438552d82", null ],
    [ "HeightToNormalMap", "class_as_imp_l_1_1_model_util.html#a38fbbfa64de164325e980543e78fd7ad", null ],
    [ "ScanTransparentPixels", "class_as_imp_l_1_1_model_util.html#a108deb31557be688e8e900caff4fa069", null ],
    [ "SetupMaterialWithBlendMode", "class_as_imp_l_1_1_model_util.html#a805d540df6bb1edd7e02782867bc681c", null ]
];