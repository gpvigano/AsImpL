var searchData=
[
  ['dataset',['dataSet',['../class_as_imp_l_1_1_loader.html#a4c3e3792f1e072fe29cd1c65ac532966',1,'AsImpL::Loader']]],
  ['diffusecolor',['diffuseColor',['../class_as_imp_l_1_1_material_data.html#a2d1f9a823cdeb37603944ce5a09d1410',1,'AsImpL::MaterialData']]],
  ['diffusetex',['diffuseTex',['../class_as_imp_l_1_1_material_data.html#a0060fb2140b7b8b75b52e0c220d85f5c',1,'AsImpL::MaterialData']]],
  ['diffusetexpath',['diffuseTexPath',['../class_as_imp_l_1_1_material_data.html#a8fa4ffcc225ca14dee5bfe328f38ccf2',1,'AsImpL::MaterialData']]]
];
