var searchData=
[
  ['facegroupdata',['FaceGroupData',['../class_as_imp_l_1_1_data_set_1_1_face_group_data.html#a6c495333ef0c5274ee164805952f3875',1,'AsImpL::DataSet::FaceGroupData']]]
];
