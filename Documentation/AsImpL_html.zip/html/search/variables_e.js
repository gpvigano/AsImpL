var searchData=
[
  ['shininess',['shininess',['../class_as_imp_l_1_1_material_data.html#ac2799ad8e55055e68b95b89bd2867586',1,'AsImpL::MaterialData']]],
  ['specularcolor',['specularColor',['../class_as_imp_l_1_1_material_data.html#ab8dac0cd70b2346f509672cd960b4368',1,'AsImpL::MaterialData']]],
  ['speculartex',['specularTex',['../class_as_imp_l_1_1_material_data.html#ac715a373a81e29a949a34198ee923ae3',1,'AsImpL::MaterialData']]],
  ['speculartexpath',['specularTexPath',['../class_as_imp_l_1_1_material_data.html#a7ba3b29e12ce1dc8ab54f85524430449',1,'AsImpL::MaterialData']]]
];
