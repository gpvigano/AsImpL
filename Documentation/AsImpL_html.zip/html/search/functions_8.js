var searchData=
[
  ['objectdata',['ObjectData',['../class_as_imp_l_1_1_data_set_1_1_object_data.html#a818634114295b31e27c98c3b273d76cc',1,'AsImpL::DataSet::ObjectData']]],
  ['onimportingcomplete',['OnImportingComplete',['../class_as_imp_l_1_1_object_importer.html#a8718ffb1d10e53559efc0ca93e0a174e',1,'AsImpL::ObjectImporter']]]
];
