var class_as_imp_l_1_1_material_data =
[
    [ "ambientColor", "class_as_imp_l_1_1_material_data.html#aab1d5c872f78cfe17bb35776456862b6", null ],
    [ "bumpTex", "class_as_imp_l_1_1_material_data.html#ad655bdedd63eaee103db39b33c1de27d", null ],
    [ "bumpTexPath", "class_as_imp_l_1_1_material_data.html#abff58f1fabe751eca3e65928e3257a5d", null ],
    [ "diffuseColor", "class_as_imp_l_1_1_material_data.html#a2d1f9a823cdeb37603944ce5a09d1410", null ],
    [ "diffuseTex", "class_as_imp_l_1_1_material_data.html#a0060fb2140b7b8b75b52e0c220d85f5c", null ],
    [ "diffuseTexPath", "class_as_imp_l_1_1_material_data.html#a8fa4ffcc225ca14dee5bfe328f38ccf2", null ],
    [ "hasReflectionTex", "class_as_imp_l_1_1_material_data.html#a441644de9667941e26f078addf7b0f15", null ],
    [ "illumType", "class_as_imp_l_1_1_material_data.html#ae8206f2f949ecb6408da946a2ee05c00", null ],
    [ "materialName", "class_as_imp_l_1_1_material_data.html#a9661889ff5ac093acb78e6f547e65759", null ],
    [ "opacityTex", "class_as_imp_l_1_1_material_data.html#a970a2fdb1d1cc68533fbc47a9a0c6a2f", null ],
    [ "opacityTexPath", "class_as_imp_l_1_1_material_data.html#aca45d2e8da9304115c30de87817e6473", null ],
    [ "overallAlpha", "class_as_imp_l_1_1_material_data.html#a1f32eb2516d9cfaae77556aa6545602a", null ],
    [ "shininess", "class_as_imp_l_1_1_material_data.html#ac2799ad8e55055e68b95b89bd2867586", null ],
    [ "specularColor", "class_as_imp_l_1_1_material_data.html#ab8dac0cd70b2346f509672cd960b4368", null ],
    [ "specularTex", "class_as_imp_l_1_1_material_data.html#ac715a373a81e29a949a34198ee923ae3", null ],
    [ "specularTexPath", "class_as_imp_l_1_1_material_data.html#a7ba3b29e12ce1dc8ab54f85524430449", null ]
];