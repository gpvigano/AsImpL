var class_as_imp_l_1_1_import_options =
[
    [ "litDiffuse", "class_as_imp_l_1_1_import_options.html#ad11146ff6006e70dab3832ba6bf5268a", null ],
    [ "localEulerAngles", "class_as_imp_l_1_1_import_options.html#ae5510104b3d29d67dba96c0ce0556756", null ],
    [ "localPosition", "class_as_imp_l_1_1_import_options.html#aadb3bdf439a5ec6be970236d19725324", null ],
    [ "localScale", "class_as_imp_l_1_1_import_options.html#ac3c17fb7abdd69d25ead89cc6c7d7b08", null ],
    [ "modelScaling", "class_as_imp_l_1_1_import_options.html#ade4100426127f74dea6dbd4e7a9f8403", null ],
    [ "reuseLoaded", "class_as_imp_l_1_1_import_options.html#ac247bc50d7abf7cc082f181d5fb4af88", null ],
    [ "zUp", "class_as_imp_l_1_1_import_options.html#ac580d539a364137aa95805005036620d", null ]
];