var struct_as_imp_l_1_1_data_set_1_1_face_indices =
[
    [ "normIdx", "struct_as_imp_l_1_1_data_set_1_1_face_indices.html#a0f3a01e0a56d7611a378209b6196c729", null ],
    [ "uvIdx", "struct_as_imp_l_1_1_data_set_1_1_face_indices.html#a6ca38a8a8164e1c2453f95ac73ca1187", null ],
    [ "vertIdx", "struct_as_imp_l_1_1_data_set_1_1_face_indices.html#a5a28a54349eff36bf852829eb7e86620", null ]
];