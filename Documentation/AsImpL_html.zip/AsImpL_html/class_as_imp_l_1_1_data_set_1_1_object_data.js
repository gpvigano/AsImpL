var class_as_imp_l_1_1_data_set_1_1_object_data =
[
    [ "ObjectData", "class_as_imp_l_1_1_data_set_1_1_object_data.html#a818634114295b31e27c98c3b273d76cc", null ],
    [ "allFaces", "class_as_imp_l_1_1_data_set_1_1_object_data.html#a6f0e4f3b5fb3787916b226ac217158d8", null ],
    [ "faceGroups", "class_as_imp_l_1_1_data_set_1_1_object_data.html#a4c4de2d1dcc7da0d4173c252123456ba", null ],
    [ "hasColors", "class_as_imp_l_1_1_data_set_1_1_object_data.html#aa3243480bbda93dadde1681998f3c6a2", null ],
    [ "hasNormals", "class_as_imp_l_1_1_data_set_1_1_object_data.html#ab615aa67fcffbcb69eb5bdbc2fb70732", null ],
    [ "name", "class_as_imp_l_1_1_data_set_1_1_object_data.html#af5914f75d1e31b54fea505a47973c723", null ]
];