var class_as_imp_l_1_1_single_loading_progress =
[
    [ "error", "class_as_imp_l_1_1_single_loading_progress.html#ad774a3d8944ac8594925850c758e4dbd", null ],
    [ "fileName", "class_as_imp_l_1_1_single_loading_progress.html#a04ff0b1fd2a6e7494e64386cd75cc771", null ],
    [ "message", "class_as_imp_l_1_1_single_loading_progress.html#a837803abe2b87bf1fd44a0b6b217ba5e", null ],
    [ "numObjects", "class_as_imp_l_1_1_single_loading_progress.html#a0d3b8ceb94b80c1d0fe2ae98e7c7cb43", null ],
    [ "numSubObjects", "class_as_imp_l_1_1_single_loading_progress.html#a90528402af44fa92adb9fc893d61e98a", null ],
    [ "percentage", "class_as_imp_l_1_1_single_loading_progress.html#a22f321d6f57307ff3552172d77fe81c4", null ]
];