var struct_as_imp_l_1_1_loader_1_1_stats =
[
    [ "buildStats", "struct_as_imp_l_1_1_loader_1_1_stats.html#af5e3dec020025260e88699241de8fd8c", null ],
    [ "buildTime", "struct_as_imp_l_1_1_loader_1_1_stats.html#a61b038492a598041e4426279d78134ae", null ],
    [ "materialsParseTime", "struct_as_imp_l_1_1_loader_1_1_stats.html#a74b384fb0e443b27dc0c2bceb24c66ca", null ],
    [ "modelParseTime", "struct_as_imp_l_1_1_loader_1_1_stats.html#a10c90709b23d6ec1bc0a158cbce137c9", null ],
    [ "totalTime", "struct_as_imp_l_1_1_loader_1_1_stats.html#afc4d84732f9846572b25d59a7c27b5fe", null ]
];