var searchData=
[
  ['name_0',['name',['../class_as_imp_l_1_1_data_set_1_1_object_data.html#af5914f75d1e31b54fea505a47973c723',1,'AsImpL.DataSet.ObjectData.name()'],['../class_as_imp_l_1_1_data_set_1_1_face_group_data.html#aa31c81bbe144f09126bb1c983e8c0171',1,'AsImpL.DataSet.FaceGroupData.name()'],['../class_as_imp_l_1_1_model_import_info.html#a278955a08f9b2bc33284b927f11839d5',1,'AsImpL.ModelImportInfo.name()']]],
  ['normallist_1',['normalList',['../class_as_imp_l_1_1_data_set.html#a27b4af38fe4b9269619d9232f211fc62',1,'AsImpL::DataSet']]],
  ['normidx_2',['normIdx',['../struct_as_imp_l_1_1_data_set_1_1_face_indices.html#a0f3a01e0a56d7611a378209b6196c729',1,'AsImpL::DataSet::FaceIndices']]],
  ['numgroups_3',['numGroups',['../class_as_imp_l_1_1_object_builder_1_1_progress_info.html#a1db2c31cf7f39c2fe92227b2e5496cd1',1,'AsImpL::ObjectBuilder::ProgressInfo']]],
  ['numobjects_4',['numObjects',['../class_as_imp_l_1_1_single_loading_progress.html#a0d3b8ceb94b80c1d0fe2ae98e7c7cb43',1,'AsImpL::SingleLoadingProgress']]],
  ['numsubobjects_5',['numSubObjects',['../class_as_imp_l_1_1_single_loading_progress.html#a90528402af44fa92adb9fc893d61e98a',1,'AsImpL::SingleLoadingProgress']]],
  ['numtotalimports_6',['numTotalImports',['../class_as_imp_l_1_1_object_importer.html#aaeea55a8169b531687669dffee07b125',1,'AsImpL::ObjectImporter']]]
];
