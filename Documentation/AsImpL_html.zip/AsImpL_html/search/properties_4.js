var searchData=
[
  ['importedmaterials_0',['ImportedMaterials',['../class_as_imp_l_1_1_object_builder.html#a403edfcdfbfccd6bebaebbbc728ef535',1,'AsImpL::ObjectBuilder']]],
  ['isempty_1',['IsEmpty',['../class_as_imp_l_1_1_data_set.html#a73cd32b0e339024107d4421443c550e1',1,'AsImpL.DataSet.IsEmpty()'],['../class_as_imp_l_1_1_data_set_1_1_face_group_data.html#a2a2324d02c9ec02f061dfac450f8fdc7',1,'AsImpL.DataSet.FaceGroupData.IsEmpty()']]]
];
