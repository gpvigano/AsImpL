var searchData=
[
  ['numimportedmaterials',['NumImportedMaterials',['../class_as_imp_l_1_1_object_builder.html#a8df71484c3f6b97086e16fc02384d50a',1,'AsImpL::ObjectBuilder']]],
  ['numimportrequests',['NumImportRequests',['../class_as_imp_l_1_1_object_importer.html#a677d462373fc805f874bd0907ff9a86d',1,'AsImpL::ObjectImporter']]]
];
