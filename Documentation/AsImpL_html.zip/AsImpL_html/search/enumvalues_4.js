var searchData=
[
  ['persistentdatapath_0',['PersistentDataPath',['../namespace_as_imp_l.html#a774bca8673a7d734120bb3edfc51f0c3aa719b7977a39d032029f3567d4499e0b',1,'AsImpL']]]
];
