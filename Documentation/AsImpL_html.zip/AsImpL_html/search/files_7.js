var searchData=
[
  ['pathsettings_2ecs_0',['PathSettings.cs',['../_path_settings_8cs.html',1,'']]]
];
