var searchData=
[
  ['shininess_0',['shininess',['../class_as_imp_l_1_1_material_data.html#ac2799ad8e55055e68b95b89bd2867586',1,'AsImpL::MaterialData']]],
  ['singleprogress_1',['singleProgress',['../class_as_imp_l_1_1_loading_progress.html#ac45ca10d1f03722986ba0d3f5a3784ac',1,'AsImpL::LoadingProgress']]],
  ['skip_2',['skip',['../class_as_imp_l_1_1_model_import_info.html#acfa30917e7d783c4d795738cc9c6b32c',1,'AsImpL::ModelImportInfo']]],
  ['specularcolor_3',['specularColor',['../class_as_imp_l_1_1_material_data.html#ab8dac0cd70b2346f509672cd960b4368',1,'AsImpL::MaterialData']]],
  ['speculartex_4',['specularTex',['../class_as_imp_l_1_1_material_data.html#ac715a373a81e29a949a34198ee923ae3',1,'AsImpL::MaterialData']]],
  ['speculartexpath_5',['specularTexPath',['../class_as_imp_l_1_1_material_data.html#a7ba3b29e12ce1dc8ab54f85524430449',1,'AsImpL::MaterialData']]]
];
