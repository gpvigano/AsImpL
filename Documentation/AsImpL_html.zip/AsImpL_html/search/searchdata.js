var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvz",
  1: "bdfilmopstv",
  2: "a",
  3: "deilmotv",
  4: "abcdfghilopstuv",
  5: "abcdefghilmnoprstuvz",
  6: "m",
  7: "cfot",
  8: "achinopst",
  9: "cim",
  10: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events",
  10: "Pages"
};

