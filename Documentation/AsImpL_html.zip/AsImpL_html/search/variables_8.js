var searchData=
[
  ['illumtype',['illumType',['../class_as_imp_l_1_1_material_data.html#ae8206f2f949ecb6408da946a2ee05c00',1,'AsImpL::MaterialData']]],
  ['importassets',['importAssets',['../class_as_imp_l_1_1_object_importer.html#a8a068a6c374ebd4f366bf6203729d3bd',1,'AsImpL::ObjectImporter']]],
  ['instancecount',['instanceCount',['../class_as_imp_l_1_1_loader.html#a120373860a0cfea6a53046da8c253aa8',1,'AsImpL::Loader']]]
];
