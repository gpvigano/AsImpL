var searchData=
[
  ['convertvertaxis_0',['ConvertVertAxis',['../class_as_imp_l_1_1_loader.html#a0691ab9426683f12d9494e186c6ba5b3',1,'AsImpL::Loader']]],
  ['currgroupname_1',['CurrGroupName',['../class_as_imp_l_1_1_data_set.html#a8505366102c62e573b505cfc32d42c76',1,'AsImpL::DataSet']]]
];
