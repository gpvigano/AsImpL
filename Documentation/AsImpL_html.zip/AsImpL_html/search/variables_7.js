var searchData=
[
  ['hascolors',['hasColors',['../class_as_imp_l_1_1_data_set_1_1_object_data.html#aa3243480bbda93dadde1681998f3c6a2',1,'AsImpL::DataSet::ObjectData']]],
  ['hasnormals',['hasNormals',['../class_as_imp_l_1_1_data_set_1_1_object_data.html#ab615aa67fcffbcb69eb5bdbc2fb70732',1,'AsImpL::DataSet::ObjectData']]],
  ['hasreflectiontex',['hasReflectionTex',['../class_as_imp_l_1_1_material_data.html#a441644de9667941e26f078addf7b0f15',1,'AsImpL::MaterialData']]]
];
