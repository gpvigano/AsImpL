var searchData=
[
  ['allfaces',['allFaces',['../class_as_imp_l_1_1_data_set_1_1_object_data.html#a6f0e4f3b5fb3787916b226ac217158d8',1,'AsImpL::DataSet::ObjectData']]],
  ['allloaded',['allLoaded',['../class_as_imp_l_1_1_object_importer.html#a58c0d1ed138722dcfa99dbb60f1e7c43',1,'AsImpL::ObjectImporter']]],
  ['ambientcolor',['ambientColor',['../class_as_imp_l_1_1_material_data.html#aab1d5c872f78cfe17bb35776456862b6',1,'AsImpL::MaterialData']]]
];
