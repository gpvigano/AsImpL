var searchData=
[
  ['dataset_0',['DataSet',['../class_as_imp_l_1_1_data_set.html',1,'AsImpL']]]
];
