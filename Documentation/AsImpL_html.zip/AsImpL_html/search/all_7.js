var searchData=
[
  ['hascolors_0',['hasColors',['../class_as_imp_l_1_1_data_set_1_1_object_data.html#aa3243480bbda93dadde1681998f3c6a2',1,'AsImpL::DataSet::ObjectData']]],
  ['hasmateriallibrary_1',['HasMaterialLibrary',['../class_as_imp_l_1_1_loader.html#a8f4b95ab1b77af156e886d9f5fce3ff9',1,'AsImpL.Loader.HasMaterialLibrary()'],['../class_as_imp_l_1_1_loader_obj.html#af15ac22b798d8d7eff31d21cb3905db4',1,'AsImpL.LoaderObj.HasMaterialLibrary()']]],
  ['hasnormals_2',['hasNormals',['../class_as_imp_l_1_1_data_set_1_1_object_data.html#ab615aa67fcffbcb69eb5bdbc2fb70732',1,'AsImpL::DataSet::ObjectData']]],
  ['hasreflectiontex_3',['hasReflectionTex',['../class_as_imp_l_1_1_material_data.html#a441644de9667941e26f078addf7b0f15',1,'AsImpL::MaterialData']]],
  ['heighttonormalmap_4',['HeightToNormalMap',['../class_as_imp_l_1_1_model_util.html#a38fbbfa64de164325e980543e78fd7ad',1,'AsImpL::ModelUtil']]],
  ['hidewhileloading_5',['hideWhileLoading',['../class_as_imp_l_1_1_import_options.html#ac0a6e99489008fed982e085261f6ca2b',1,'AsImpL::ImportOptions']]]
];
