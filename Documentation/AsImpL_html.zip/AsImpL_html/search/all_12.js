var searchData=
[
  ['vertidx',['vertIdx',['../struct_as_imp_l_1_1_data_set_1_1_face_indices.html#a5a28a54349eff36bf852829eb7e86620',1,'AsImpL::DataSet::FaceIndices']]],
  ['vertlist',['vertList',['../class_as_imp_l_1_1_data_set.html#a11f4ca8eab857d194ed56b935a325b2d',1,'AsImpL::DataSet']]]
];
