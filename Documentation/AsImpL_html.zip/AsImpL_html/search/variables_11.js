var searchData=
[
  ['uvidx_0',['uvIdx',['../struct_as_imp_l_1_1_data_set_1_1_face_indices.html#a6ca38a8a8164e1c2453f95ac73ca1187',1,'AsImpL::DataSet::FaceIndices']]],
  ['uvlist_1',['uvList',['../class_as_imp_l_1_1_data_set.html#a23b0ef3e34673553ba011dd7afa2f6d8',1,'AsImpL::DataSet']]]
];
