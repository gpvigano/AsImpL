var searchData=
[
  ['readallbytes_0',['ReadAllBytes',['../class_as_imp_l_1_1_file_filesystem.html#aa38ee75bfb9ccc4872272f4792883ca8',1,'AsImpL.FileFilesystem.ReadAllBytes()'],['../interface_as_imp_l_1_1_i_filesystem.html#adc2a2fb8b5f535d007ec778af1a59126',1,'AsImpL.IFilesystem.ReadAllBytes()']]],
  ['readalllines_1',['ReadAllLines',['../class_as_imp_l_1_1_file_filesystem.html#a5e2ecf9e357350f3bd8adc7285cf4e06',1,'AsImpL.FileFilesystem.ReadAllLines()'],['../interface_as_imp_l_1_1_i_filesystem.html#a3b18308d90a5d7fc69af9e44ae9d5bfa',1,'AsImpL.IFilesystem.ReadAllLines()']]]
];
