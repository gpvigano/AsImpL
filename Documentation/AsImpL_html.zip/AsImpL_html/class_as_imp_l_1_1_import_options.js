var class_as_imp_l_1_1_import_options =
[
    [ "buildColliders", "class_as_imp_l_1_1_import_options.html#a36b4e2552638c830eb68473de0e34609", null ],
    [ "colliderConvex", "class_as_imp_l_1_1_import_options.html#a2cf9dc11a7d06a36d854bb508ba82b33", null ],
    [ "colliderInflate", "class_as_imp_l_1_1_import_options.html#af4b904010accd34d7d6f906616fb26fa", null ],
    [ "colliderSkinWidth", "class_as_imp_l_1_1_import_options.html#af31dffb650f9852241a56c55377ccd34", null ],
    [ "colliderTrigger", "class_as_imp_l_1_1_import_options.html#acf603d45c94919e0dd462017fd97c538", null ],
    [ "convertToDoubleSided", "class_as_imp_l_1_1_import_options.html#a48d7e841f9195edbbf09918ae3cfcc79", null ],
    [ "inheritLayer", "class_as_imp_l_1_1_import_options.html#a462cfdbf3247ed5e1d64bfbab3e016c1", null ],
    [ "litDiffuse", "class_as_imp_l_1_1_import_options.html#ad11146ff6006e70dab3832ba6bf5268a", null ],
    [ "localEulerAngles", "class_as_imp_l_1_1_import_options.html#ae5510104b3d29d67dba96c0ce0556756", null ],
    [ "localPosition", "class_as_imp_l_1_1_import_options.html#aadb3bdf439a5ec6be970236d19725324", null ],
    [ "localScale", "class_as_imp_l_1_1_import_options.html#ac3c17fb7abdd69d25ead89cc6c7d7b08", null ],
    [ "modelScaling", "class_as_imp_l_1_1_import_options.html#ade4100426127f74dea6dbd4e7a9f8403", null ],
    [ "reuseLoaded", "class_as_imp_l_1_1_import_options.html#ac247bc50d7abf7cc082f181d5fb4af88", null ],
    [ "zUp", "class_as_imp_l_1_1_import_options.html#ac580d539a364137aa95805005036620d", null ]
];