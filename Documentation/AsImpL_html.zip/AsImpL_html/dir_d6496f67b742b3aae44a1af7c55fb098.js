var dir_d6496f67b742b3aae44a1af7c55fb098 =
[
    [ "DataSet.cs", "_data_set_8cs.html", [
      [ "DataSet", "class_as_imp_l_1_1_data_set.html", "class_as_imp_l_1_1_data_set" ],
      [ "FaceIndices", "struct_as_imp_l_1_1_data_set_1_1_face_indices.html", "struct_as_imp_l_1_1_data_set_1_1_face_indices" ],
      [ "ObjectData", "class_as_imp_l_1_1_data_set_1_1_object_data.html", "class_as_imp_l_1_1_data_set_1_1_object_data" ],
      [ "FaceGroupData", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html", "class_as_imp_l_1_1_data_set_1_1_face_group_data" ]
    ] ],
    [ "MaterialData.cs", "_material_data_8cs.html", [
      [ "MaterialData", "class_as_imp_l_1_1_material_data.html", "class_as_imp_l_1_1_material_data" ]
    ] ],
    [ "ModelUtil.cs", "_model_util_8cs.html", [
      [ "ModelUtil", "class_as_imp_l_1_1_model_util.html", "class_as_imp_l_1_1_model_util" ]
    ] ],
    [ "ObjectBuilder.cs", "_object_builder_8cs.html", [
      [ "ObjectBuilder", "class_as_imp_l_1_1_object_builder.html", "class_as_imp_l_1_1_object_builder" ],
      [ "ProgressInfo", "class_as_imp_l_1_1_object_builder_1_1_progress_info.html", "class_as_imp_l_1_1_object_builder_1_1_progress_info" ]
    ] ],
    [ "Triangulator.cs", "_triangulator_8cs.html", [
      [ "Triangulator", "class_as_imp_l_1_1_triangulator.html", "class_as_imp_l_1_1_triangulator" ]
    ] ]
];