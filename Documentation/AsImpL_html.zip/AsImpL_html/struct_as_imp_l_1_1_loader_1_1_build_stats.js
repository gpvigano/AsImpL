var struct_as_imp_l_1_1_loader_1_1_build_stats =
[
    [ "materialsTime", "struct_as_imp_l_1_1_loader_1_1_build_stats.html#a55d8bc067f37c634e7183646c1db5b60", null ],
    [ "objectsTime", "struct_as_imp_l_1_1_loader_1_1_build_stats.html#a9ade6ec224f4243e17fa770d14e3340c", null ],
    [ "texturesTime", "struct_as_imp_l_1_1_loader_1_1_build_stats.html#a5070152de8a1de232f4339dd7685f5a2", null ]
];