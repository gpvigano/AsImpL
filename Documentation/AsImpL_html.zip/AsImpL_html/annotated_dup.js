var annotated_dup =
[
    [ "AsImpL", "namespace_as_imp_l.html", [
      [ "MathUtil", "namespace_as_imp_l_1_1_math_util.html", [
        [ "MathUtility", "class_as_imp_l_1_1_math_util_1_1_math_utility.html", "class_as_imp_l_1_1_math_util_1_1_math_utility" ],
        [ "Triangle", "class_as_imp_l_1_1_math_util_1_1_triangle.html", "class_as_imp_l_1_1_math_util_1_1_triangle" ],
        [ "Triangulation", "class_as_imp_l_1_1_math_util_1_1_triangulation.html", "class_as_imp_l_1_1_math_util_1_1_triangulation" ],
        [ "Vertex", "class_as_imp_l_1_1_math_util_1_1_vertex.html", "class_as_imp_l_1_1_math_util_1_1_vertex" ]
      ] ],
      [ "DataSet", "class_as_imp_l_1_1_data_set.html", "class_as_imp_l_1_1_data_set" ],
      [ "FileFilesystem", "class_as_imp_l_1_1_file_filesystem.html", "class_as_imp_l_1_1_file_filesystem" ],
      [ "IFilesystem", "interface_as_imp_l_1_1_i_filesystem.html", "interface_as_imp_l_1_1_i_filesystem" ],
      [ "IMaterialFactory", "interface_as_imp_l_1_1_i_material_factory.html", "interface_as_imp_l_1_1_i_material_factory" ],
      [ "ImportOptions", "class_as_imp_l_1_1_import_options.html", "class_as_imp_l_1_1_import_options" ],
      [ "IShaderSelector", "interface_as_imp_l_1_1_i_shader_selector.html", "interface_as_imp_l_1_1_i_shader_selector" ],
      [ "Loader", "class_as_imp_l_1_1_loader.html", "class_as_imp_l_1_1_loader" ],
      [ "LoaderObj", "class_as_imp_l_1_1_loader_obj.html", "class_as_imp_l_1_1_loader_obj" ],
      [ "LoadingProgress", "class_as_imp_l_1_1_loading_progress.html", "class_as_imp_l_1_1_loading_progress" ],
      [ "MaterialData", "class_as_imp_l_1_1_material_data.html", "class_as_imp_l_1_1_material_data" ],
      [ "MaterialFactory", "class_as_imp_l_1_1_material_factory.html", "class_as_imp_l_1_1_material_factory" ],
      [ "ModelImportInfo", "class_as_imp_l_1_1_model_import_info.html", "class_as_imp_l_1_1_model_import_info" ],
      [ "ModelReferences", "class_as_imp_l_1_1_model_references.html", "class_as_imp_l_1_1_model_references" ],
      [ "ModelUtil", "class_as_imp_l_1_1_model_util.html", "class_as_imp_l_1_1_model_util" ],
      [ "MultiObjectImporter", "class_as_imp_l_1_1_multi_object_importer.html", "class_as_imp_l_1_1_multi_object_importer" ],
      [ "ObjectBuilder", "class_as_imp_l_1_1_object_builder.html", "class_as_imp_l_1_1_object_builder" ],
      [ "ObjectImporter", "class_as_imp_l_1_1_object_importer.html", "class_as_imp_l_1_1_object_importer" ],
      [ "ObjectImporterUI", "class_as_imp_l_1_1_object_importer_u_i.html", "class_as_imp_l_1_1_object_importer_u_i" ],
      [ "ObjImportWindow", "class_as_imp_l_1_1_obj_import_window.html", "class_as_imp_l_1_1_obj_import_window" ],
      [ "PathSettings", "class_as_imp_l_1_1_path_settings.html", "class_as_imp_l_1_1_path_settings" ],
      [ "ShaderSelector", "class_as_imp_l_1_1_shader_selector.html", "class_as_imp_l_1_1_shader_selector" ],
      [ "SingleLoadingProgress", "class_as_imp_l_1_1_single_loading_progress.html", "class_as_imp_l_1_1_single_loading_progress" ],
      [ "TextureLoader", "class_as_imp_l_1_1_texture_loader.html", "class_as_imp_l_1_1_texture_loader" ],
      [ "Triangulator", "class_as_imp_l_1_1_triangulator.html", "class_as_imp_l_1_1_triangulator" ]
    ] ]
];