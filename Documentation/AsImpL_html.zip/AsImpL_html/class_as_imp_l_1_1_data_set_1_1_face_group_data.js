var class_as_imp_l_1_1_data_set_1_1_face_group_data =
[
    [ "FaceGroupData", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html#a6c495333ef0c5274ee164805952f3875", null ],
    [ "faces", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html#a5ddc97ec11292ef13ca079a2f4ca9401", null ],
    [ "materialName", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html#a472e9f382595339d4caca4a80fc1a27e", null ],
    [ "name", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html#aa31c81bbe144f09126bb1c983e8c0171", null ],
    [ "IsEmpty", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html#a2a2324d02c9ec02f061dfac450f8fdc7", null ]
];