var class_as_imp_l_1_1_data_set =
[
    [ "FaceGroupData", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html", "class_as_imp_l_1_1_data_set_1_1_face_group_data" ],
    [ "FaceIndices", "struct_as_imp_l_1_1_data_set_1_1_face_indices.html", "struct_as_imp_l_1_1_data_set_1_1_face_indices" ],
    [ "ObjectData", "class_as_imp_l_1_1_data_set_1_1_object_data.html", "class_as_imp_l_1_1_data_set_1_1_object_data" ],
    [ "DataSet", "class_as_imp_l_1_1_data_set.html#a7d371aa047fec1df39e7f0a483b2523a", null ],
    [ "AddColor", "class_as_imp_l_1_1_data_set.html#a1b70e299c815700dea830648ae23e982", null ],
    [ "AddFaceIndices", "class_as_imp_l_1_1_data_set.html#a5e80b13ef653c10e1bf97678e8175bd9", null ],
    [ "AddGroup", "class_as_imp_l_1_1_data_set.html#ae4b019a9f6415ea92902d845f83e62e6", null ],
    [ "AddMaterialName", "class_as_imp_l_1_1_data_set.html#a7f8cead3662a8f2db3f5d7c28c41ee5e", null ],
    [ "AddNormal", "class_as_imp_l_1_1_data_set.html#af1be40f260a2fa32e18f2bcb9e8d85aa", null ],
    [ "AddObject", "class_as_imp_l_1_1_data_set.html#a995193488135ef548747d933704ad8f3", null ],
    [ "AddUV", "class_as_imp_l_1_1_data_set.html#a6f80db79412908a1d7d4f9177420a36f", null ],
    [ "AddVertex", "class_as_imp_l_1_1_data_set.html#afecc296fbfb87c3b7ad1f43868e72ec2", null ],
    [ "FixMaterialName", "class_as_imp_l_1_1_data_set.html#a67b40e956aeebb33159e92cfd3933615", null ],
    [ "GetFaceIndicesKey", "class_as_imp_l_1_1_data_set.html#a9e7a7a35245edbc0530097551bd664f5", null ],
    [ "PrintSummary", "class_as_imp_l_1_1_data_set.html#ac462e068ba3c192b9769b0ee164f9921", null ],
    [ "colorList", "class_as_imp_l_1_1_data_set.html#a8f43dea15dff1f3c01c670f31f1141c3", null ],
    [ "normalList", "class_as_imp_l_1_1_data_set.html#a27b4af38fe4b9269619d9232f211fc62", null ],
    [ "objectList", "class_as_imp_l_1_1_data_set.html#a74fc41752f5d004a5898002d3c5b6b31", null ],
    [ "uvList", "class_as_imp_l_1_1_data_set.html#a23b0ef3e34673553ba011dd7afa2f6d8", null ],
    [ "vertList", "class_as_imp_l_1_1_data_set.html#a11f4ca8eab857d194ed56b935a325b2d", null ],
    [ "IsEmpty", "class_as_imp_l_1_1_data_set.html#a73cd32b0e339024107d4421443c550e1", null ]
];