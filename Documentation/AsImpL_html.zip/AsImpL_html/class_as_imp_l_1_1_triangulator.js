var class_as_imp_l_1_1_triangulator =
[
    [ "FindPlaneNormal", "class_as_imp_l_1_1_triangulator.html#a9efdfe16d5b0520bb08c1155b6b2b1f6", null ],
    [ "Triangulate", "class_as_imp_l_1_1_triangulator.html#a7611c54dc759d63c0d63dd70c8a4a746", null ]
];