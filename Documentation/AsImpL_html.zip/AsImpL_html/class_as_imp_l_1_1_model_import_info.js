var class_as_imp_l_1_1_model_import_info =
[
    [ "ModelImportInfo", "class_as_imp_l_1_1_model_import_info.html#adddcaa528ef5c51476b59c7113834644", null ],
    [ "loaderOptions", "class_as_imp_l_1_1_model_import_info.html#af2f193fa6567ee0da167e813ca15ab7d", null ],
    [ "name", "class_as_imp_l_1_1_model_import_info.html#a278955a08f9b2bc33284b927f11839d5", null ],
    [ "path", "class_as_imp_l_1_1_model_import_info.html#ae876caab83d848449b3b95ac76ec1320", null ],
    [ "skip", "class_as_imp_l_1_1_model_import_info.html#acfa30917e7d783c4d795738cc9c6b32c", null ]
];