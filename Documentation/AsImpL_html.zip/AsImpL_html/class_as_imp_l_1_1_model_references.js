var class_as_imp_l_1_1_model_references =
[
    [ "AddMaterial", "class_as_imp_l_1_1_model_references.html#ad7cf8b43ce380eccf9188a95df38b074", null ],
    [ "AddMesh", "class_as_imp_l_1_1_model_references.html#a5980beff58b334c89389bdbd446bbebb", null ],
    [ "AddTexture", "class_as_imp_l_1_1_model_references.html#adefbd0c409ad8166c5fb81ae1f1aa7f3", null ]
];