var class_as_imp_l_1_1_material_factory =
[
    [ "Create", "class_as_imp_l_1_1_material_factory.html#ab95b36f74a91dc89e0b80af3558abea4", null ]
];