var hierarchy =
[
    [ "AsImpL.Loader.BuildStats", "struct_as_imp_l_1_1_loader_1_1_build_stats.html", null ],
    [ "AsImpL.DataSet", "class_as_imp_l_1_1_data_set.html", null ],
    [ "EditorWindow", null, [
      [ "AsImpL.ObjImportWindow", "class_as_imp_l_1_1_obj_import_window.html", null ]
    ] ],
    [ "AsImpL.DataSet.FaceGroupData", "class_as_imp_l_1_1_data_set_1_1_face_group_data.html", null ],
    [ "AsImpL.DataSet.FaceIndices", "struct_as_imp_l_1_1_data_set_1_1_face_indices.html", null ],
    [ "AsImpL.FileLoadingProgress", "class_as_imp_l_1_1_file_loading_progress.html", null ],
    [ "AsImpL.ImportOptions", "class_as_imp_l_1_1_import_options.html", null ],
    [ "AsImpL.LoadingProgress", "class_as_imp_l_1_1_loading_progress.html", null ],
    [ "AsImpL.MaterialData", "class_as_imp_l_1_1_material_data.html", null ],
    [ "AsImpL.MathUtil.MathUtility", "class_as_imp_l_1_1_math_util_1_1_math_utility.html", null ],
    [ "AsImpL.ModelUtil", "class_as_imp_l_1_1_model_util.html", null ],
    [ "MonoBehaviour", null, [
      [ "AsImpL.Loader", "class_as_imp_l_1_1_loader.html", [
        [ "AsImpL.LoaderObj", "class_as_imp_l_1_1_loader_obj.html", null ]
      ] ],
      [ "AsImpL.ObjectImporter", "class_as_imp_l_1_1_object_importer.html", null ],
      [ "AsImpL.ObjectImporterUI", "class_as_imp_l_1_1_object_importer_u_i.html", null ],
      [ "AsImpL.TextureLoader", "class_as_imp_l_1_1_texture_loader.html", null ]
    ] ],
    [ "AsImpL.ObjectBuilder", "class_as_imp_l_1_1_object_builder.html", null ],
    [ "AsImpL.DataSet.ObjectData", "class_as_imp_l_1_1_data_set_1_1_object_data.html", null ],
    [ "AsImpL.ObjectBuilder.ProgressInfo", "class_as_imp_l_1_1_object_builder_1_1_progress_info.html", null ],
    [ "AsImpL.Loader.Stats", "struct_as_imp_l_1_1_loader_1_1_stats.html", null ],
    [ "AsImpL.MathUtil.Triangle", "class_as_imp_l_1_1_math_util_1_1_triangle.html", null ],
    [ "AsImpL.MathUtil.Triangulation", "class_as_imp_l_1_1_math_util_1_1_triangulation.html", null ],
    [ "AsImpL.Triangulator", "class_as_imp_l_1_1_triangulator.html", null ],
    [ "AsImpL.MathUtil.Vertex", "class_as_imp_l_1_1_math_util_1_1_vertex.html", null ]
];