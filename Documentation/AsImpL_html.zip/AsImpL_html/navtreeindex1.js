var NAVTREEINDEX1 =
{
"struct_as_imp_l_1_1_loader_1_1_stats.html#af5e3dec020025260e88699241de8fd8c":[2,0,0,4,1,0],
"struct_as_imp_l_1_1_loader_1_1_stats.html#afc4d84732f9846572b25d59a7c27b5fe":[2,0,0,4,1,4]
};
